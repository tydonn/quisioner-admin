<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald07245451647f5715f9bac44fc38d4f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald07245451647f5715f9bac44fc38d4f4 = $attributes; } ?>
<?php $component = App\View\Components\Common\PageBreadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.page-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\PageBreadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => 'From Elements']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $attributes = $__attributesOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__attributesOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald07245451647f5715f9bac44fc38d4f4)): ?>
<?php $component = $__componentOriginald07245451647f5715f9bac44fc38d4f4; ?>
<?php unset($__componentOriginald07245451647f5715f9bac44fc38d4f4); ?>
<?php endif; ?>
    <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div class="space-y-6">
            <?php if (isset($component)) { $__componentOriginalaea01ac4a262761bf5fe889864d03ee8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaea01ac4a262761bf5fe889864d03ee8 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\DefaultInputs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.default-inputs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\DefaultInputs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaea01ac4a262761bf5fe889864d03ee8)): ?>
<?php $attributes = $__attributesOriginalaea01ac4a262761bf5fe889864d03ee8; ?>
<?php unset($__attributesOriginalaea01ac4a262761bf5fe889864d03ee8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaea01ac4a262761bf5fe889864d03ee8)): ?>
<?php $component = $__componentOriginalaea01ac4a262761bf5fe889864d03ee8; ?>
<?php unset($__componentOriginalaea01ac4a262761bf5fe889864d03ee8); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal1a51c4663970e120106a31889a7790fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a51c4663970e120106a31889a7790fa = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\SelectInputs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.select-inputs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\SelectInputs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a51c4663970e120106a31889a7790fa)): ?>
<?php $attributes = $__attributesOriginal1a51c4663970e120106a31889a7790fa; ?>
<?php unset($__attributesOriginal1a51c4663970e120106a31889a7790fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a51c4663970e120106a31889a7790fa)): ?>
<?php $component = $__componentOriginal1a51c4663970e120106a31889a7790fa; ?>
<?php unset($__componentOriginal1a51c4663970e120106a31889a7790fa); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal773a1f0f13c1fea10fc5502a13fed3ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal773a1f0f13c1fea10fc5502a13fed3ce = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\TextAreaInputs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.text-area-inputs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\TextAreaInputs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal773a1f0f13c1fea10fc5502a13fed3ce)): ?>
<?php $attributes = $__attributesOriginal773a1f0f13c1fea10fc5502a13fed3ce; ?>
<?php unset($__attributesOriginal773a1f0f13c1fea10fc5502a13fed3ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal773a1f0f13c1fea10fc5502a13fed3ce)): ?>
<?php $component = $__componentOriginal773a1f0f13c1fea10fc5502a13fed3ce; ?>
<?php unset($__componentOriginal773a1f0f13c1fea10fc5502a13fed3ce); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal3f21b02e0a1d99ee53891904198580a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f21b02e0a1d99ee53891904198580a5 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\InputStates::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.input-states'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\InputStates::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f21b02e0a1d99ee53891904198580a5)): ?>
<?php $attributes = $__attributesOriginal3f21b02e0a1d99ee53891904198580a5; ?>
<?php unset($__attributesOriginal3f21b02e0a1d99ee53891904198580a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f21b02e0a1d99ee53891904198580a5)): ?>
<?php $component = $__componentOriginal3f21b02e0a1d99ee53891904198580a5; ?>
<?php unset($__componentOriginal3f21b02e0a1d99ee53891904198580a5); ?>
<?php endif; ?>
        </div>
        <div class="space-y-6">
            <?php if (isset($component)) { $__componentOriginaldf73ace8729db712c1cb5613992bdcad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf73ace8729db712c1cb5613992bdcad = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\InputGroup::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.input-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\InputGroup::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf73ace8729db712c1cb5613992bdcad)): ?>
<?php $attributes = $__attributesOriginaldf73ace8729db712c1cb5613992bdcad; ?>
<?php unset($__attributesOriginaldf73ace8729db712c1cb5613992bdcad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf73ace8729db712c1cb5613992bdcad)): ?>
<?php $component = $__componentOriginaldf73ace8729db712c1cb5613992bdcad; ?>
<?php unset($__componentOriginaldf73ace8729db712c1cb5613992bdcad); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale00f50e4b4ef6affbd2066a687ee8457 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale00f50e4b4ef6affbd2066a687ee8457 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\FileInputExample::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.file-input-example'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\FileInputExample::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale00f50e4b4ef6affbd2066a687ee8457)): ?>
<?php $attributes = $__attributesOriginale00f50e4b4ef6affbd2066a687ee8457; ?>
<?php unset($__attributesOriginale00f50e4b4ef6affbd2066a687ee8457); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale00f50e4b4ef6affbd2066a687ee8457)): ?>
<?php $component = $__componentOriginale00f50e4b4ef6affbd2066a687ee8457; ?>
<?php unset($__componentOriginale00f50e4b4ef6affbd2066a687ee8457); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal1ea4836229b9318c3768be465a6f1e62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ea4836229b9318c3768be465a6f1e62 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\CheckboxComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.checkbox-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\CheckboxComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ea4836229b9318c3768be465a6f1e62)): ?>
<?php $attributes = $__attributesOriginal1ea4836229b9318c3768be465a6f1e62; ?>
<?php unset($__attributesOriginal1ea4836229b9318c3768be465a6f1e62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ea4836229b9318c3768be465a6f1e62)): ?>
<?php $component = $__componentOriginal1ea4836229b9318c3768be465a6f1e62; ?>
<?php unset($__componentOriginal1ea4836229b9318c3768be465a6f1e62); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald8441b408cfc3dec9332a5d193dcced8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8441b408cfc3dec9332a5d193dcced8 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\RadioButtons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.radio-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\RadioButtons::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8441b408cfc3dec9332a5d193dcced8)): ?>
<?php $attributes = $__attributesOriginald8441b408cfc3dec9332a5d193dcced8; ?>
<?php unset($__attributesOriginald8441b408cfc3dec9332a5d193dcced8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8441b408cfc3dec9332a5d193dcced8)): ?>
<?php $component = $__componentOriginald8441b408cfc3dec9332a5d193dcced8; ?>
<?php unset($__componentOriginald8441b408cfc3dec9332a5d193dcced8); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4914dbe83d2866cd6648b9abec922741 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4914dbe83d2866cd6648b9abec922741 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\ToggleSwitch::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.toggle-switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\ToggleSwitch::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4914dbe83d2866cd6648b9abec922741)): ?>
<?php $attributes = $__attributesOriginal4914dbe83d2866cd6648b9abec922741; ?>
<?php unset($__attributesOriginal4914dbe83d2866cd6648b9abec922741); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4914dbe83d2866cd6648b9abec922741)): ?>
<?php $component = $__componentOriginal4914dbe83d2866cd6648b9abec922741; ?>
<?php unset($__componentOriginal4914dbe83d2866cd6648b9abec922741); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal7f0439b0018bb1ee452d27c56788da36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f0439b0018bb1ee452d27c56788da36 = $attributes; } ?>
<?php $component = App\View\Components\Form\FormElements\Dropzone::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.form-elements.dropzone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Form\FormElements\Dropzone::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f0439b0018bb1ee452d27c56788da36)): ?>
<?php $attributes = $__attributesOriginal7f0439b0018bb1ee452d27c56788da36; ?>
<?php unset($__attributesOriginal7f0439b0018bb1ee452d27c56788da36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f0439b0018bb1ee452d27c56788da36)): ?>
<?php $component = $__componentOriginal7f0439b0018bb1ee452d27c56788da36; ?>
<?php unset($__componentOriginal7f0439b0018bb1ee452d27c56788da36); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\arikn\Documents\WebDevUnmuh\tailadmin-laravel\resources\views/pages/form/form-elements.blade.php ENDPATH**/ ?>