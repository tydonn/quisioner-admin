@extends('layouts.app')

@section('content')
    <x-common.page-breadcrumb pageTitle="Calender" />
    <x-calender-area />
@endsection
