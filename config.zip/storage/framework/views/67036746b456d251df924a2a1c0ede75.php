

<div
  :class="$store.sidebar.isMobileOpen ? 'block xl:hidden' : 'hidden'"
  class="fixed z-50 h-screen w-full bg-gray-900/50"
></div>
<?php /**PATH C:\Users\arikn\Documents\WebDevUnmuh\tailadmin-laravel\resources\views/layouts/backdrop.blade.php ENDPATH**/ ?>